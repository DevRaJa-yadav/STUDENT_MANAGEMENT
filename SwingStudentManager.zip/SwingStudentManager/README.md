# SwingStudentManager (Desktop Swing + JDBC CRUD)

This is a ready-to-run Java Swing desktop application that uses MySQL via JDBC.
It's pre-configured for your database credentials (as you provided):
- username: root
- password: admin
- database: student_db

## Quick steps to run in IntelliJ

1. Ensure JDK 17+ is installed and IntelliJ uses it.
2. Open this folder in IntelliJ (`File -> Open` and pick the folder containing pom.xml).
3. Import Maven project when prompted.
4. Create the database and table (see `sql/queries.sql`) in your MySQL:
   - Database name: `student_db`
   - Table will be created by the provided SQL file.
5. Build fat jar:
   ```
   mvn clean package
   ```
   After build you will find: `target/SwingStudentManager-1.0-jar-with-dependencies.jar`
6. Run from IntelliJ or terminal:
   ```
   java -jar target/SwingStudentManager-1.0-jar-with-dependencies.jar
   ```

## Notes
- If your MySQL is on non-default host/port, edit `src/main/resources/db.properties`.
- The UI is simple: Add, Edit, Delete, Refresh list of students.

