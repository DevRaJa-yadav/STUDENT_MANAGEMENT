package app;

import dao.StudentDAO;
import model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class Main extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public Main() {
        setTitle("Student Manager - Desktop (Swing + JDBC)");
        setSize(700,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new Object[]{"ID","Name","Email","Course"}, 0) {
            public boolean isCellEditable(int row, int col){ return false; }
        };
        table = new JTable(model);
        refreshTable();

        JScrollPane sp = new JScrollPane(table);
        add(sp, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton addBtn = new JButton("Add");
        JButton editBtn = new JButton("Edit");
        JButton delBtn = new JButton("Delete");
        JButton refreshBtn = new JButton("Refresh");
        btnPanel.add(addBtn); btnPanel.add(editBtn); btnPanel.add(delBtn); btnPanel.add(refreshBtn);
        add(btnPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> showAddDialog());
        editBtn.addActionListener(e -> showEditDialog());
        delBtn.addActionListener(e -> deleteSelected());
        refreshBtn.addActionListener(e -> refreshTable());
    }

    private void refreshTable() {
        try {
            model.setRowCount(0);
            List<Student> list = StudentDAO.getAll();
            for (Student s : list) {
                model.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getCourse()});
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void showAddDialog() {
        JTextField name = new JTextField();
        JTextField email = new JTextField();
        JTextField course = new JTextField();
        Object[] msg = {"Name:", name, "Email:", email, "Course:", course};
        int ok = JOptionPane.showConfirmDialog(this, msg, "Add Student", JOptionPane.OK_CANCEL_OPTION);
        if (ok == JOptionPane.OK_OPTION) {
            try {
                StudentDAO.add(new Student(name.getText(), email.getText(), course.getText()));
                refreshTable();
            } catch (Exception ex) { showError(ex); }
        }
    }

    private void showEditDialog() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row first"); return; }
        int id = (int) model.getValueAt(row,0);
        try {
            Student s = StudentDAO.getById(id);
            if (s == null) { JOptionPane.showMessageDialog(this, "Record not found"); return; }
            JTextField name = new JTextField(s.getName());
            JTextField email = new JTextField(s.getEmail());
            JTextField course = new JTextField(s.getCourse());
            Object[] msg = {"Name:", name, "Email:", email, "Course:", course};
            int ok = JOptionPane.showConfirmDialog(this, msg, "Edit Student", JOptionPane.OK_CANCEL_OPTION);
            if (ok == JOptionPane.OK_OPTION) {
                s.setName(name.getText());
                s.setEmail(email.getText());
                s.setCourse(course.getText());
                StudentDAO.update(s);
                refreshTable();
            }
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row first"); return; }
        int id = (int) model.getValueAt(row,0);
        int ok = JOptionPane.showConfirmDialog(this, "Delete selected record?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            try {
                StudentDAO.delete(id);
                refreshTable();
            } catch (Exception ex) { showError(ex); }
        }
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
